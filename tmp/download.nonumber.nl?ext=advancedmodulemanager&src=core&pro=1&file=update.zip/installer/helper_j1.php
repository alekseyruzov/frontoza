<?php
/**
 * Helper File (for Joomla! 1.5)
 *
 * @package         NoNumber-installer
 * @version         12.8.4
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2012 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Cleanup install files/folders
 */
function cleanupInstall()
{
	$installer = JInstaller::getInstance();
	$source = str_replace('\\', '/', $installer->getPath('source'));
	$config = JFactory::getConfig();
	$tmp = dirname(str_replace('\\', '/', $config->getValue('config.tmp_path').'/x'));

	if (strpos($source, $tmp) === false || $source == $tmp) {
		return;
	}

	$package_folder = dirname($source);
	if ($package_folder == $tmp) {
		$package_folder = $source;
	}

	$package_file = '';
	switch (JRequest::getString('installtype')) {
		case 'url':
			$package_file = JRequest::getString('install_url');
			$package_file = str_replace(dirname($package_file), '', $package_file);
			break;
		case 'upload':
		default:
			if (isset($_FILES) && isset($_FILES['install_package']) && isset($_FILES['install_package']['name'])) {
				$package_file = $_FILES['install_package']['name'];
			}
			break;
	}
	if (!$package_file && $package_folder != $source) {
		$package_file = str_replace($package_folder.'/', '', $source).'.zip';
	}

	$package_file = $tmp.'/'.$package_file;

	JInstallerHelper::cleanupInstall($package_file, $package_folder);
}

/**
 * Copies language files to the specified path
 */
function installLanguagesByPath($folder, $path, $force = 1, $all = 1, $break = 1)
{
	if ($all) {
		$languages = JFolder::folders($path);
	} else {
		$lang = JFactory::getLanguage();
		$languages = array($lang->getTag());
	}
	$languages[] = 'en-GB'; // force to include the English files
	$languages = array_unique($languages);

	if (JFolder::exists($path.'/en-GB')) {
		folder_create($path.'/en-GB');
	}

	foreach ($languages as $lang) {
		if (!JFolder::exists($folder.'/'.$lang)) {
			continue;
		}
		$files = JFolder::files($folder.'/'.$lang);
		foreach ($files as $file) {
			$src = $folder.'/'.$lang.'/'.$file;
			$dest = $path.'/'.$lang.'/'.$file;
			if (!(strpos($file, '.sys.ini') === false)) {
				if (JFile::exists($dest)) {
					JFile::delete($dest);
				}
				continue;
			}
			if ($force || JFile::exists($src)) {
				if (!JFile::copy($src, $dest) && $break) {
					return 0;
				}
			}
		}
	}
	return 1;
}

function uninstallInstaller($alias = 'nonumber-installer-uninstallme')
{
	$app = JFactory::getApplication();
	// Create database object
	$db = JFactory::getDBO();

	$query = 'SELECT `id` FROM `#__components`'
		.' WHERE `option` = '.$db->quote('com_'.$alias)
		.' AND `parent` = 0'
		.' LIMIT 1';
	$db->setQuery($query);
	$id = (int) $db->loadResult();
	if ($id > 1) {
		$installer = JInstaller::getInstance();
		$installer->uninstall('component', $id);
	}
	$query = 'ALTER TABLE `#__components` AUTO_INCREMENT = 1';
	$db->setQuery($query);
	$db->query();

	// Delete language files
	$lang_folder = JPATH_ADMINISTRATOR.'/language';
	$languages = JFolder::folders($lang_folder);
	foreach ($languages as $lang) {
		$file = $lang_folder.'/'.$lang.'/'.$lang.'.com_'.$alias.'.ini';
		if (JFile::exists($file)) {
			JFile::delete($file);
		}
	}

	// Delete old language files
	$files = JFolder::files(JPATH_SITE.'/language', 'com_nonumber-installer-uninstallme.ini');
	foreach ($files as $file) {
		JFile::delete(JPATH_SITE.'/language/'.$file);
	}

	// Redirect with message
	$app->redirect('index.php?option=com_installer');
}